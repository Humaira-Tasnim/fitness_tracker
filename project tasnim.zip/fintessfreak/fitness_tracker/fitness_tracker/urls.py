from django.contrib import admin
from django.urls import path, include
from tracker.views import home  # Import the home view
from rest_framework.routers import DefaultRouter
from tracker.views import ActivityViewSet

# Set up the DRF router to handle the API routes
router = DefaultRouter()
router.register(r'activities', ActivityViewSet, basename='activity')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('tracker.urls')),
    path('', include('hydration.urls')),
    path('api/', include(router.urls)), 
    path('api/hydration', include('hydration.urls')), # API routes
]
