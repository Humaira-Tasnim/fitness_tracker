from django.shortcuts import render

# View to render the homepage (index.html)
def home(request):
    return render(request, 'tracker/index.html')

# Create your views here.
from rest_framework import viewsets
from .models import Activity
from .serializers import ActivitySerializer

class ActivityViewSet(viewsets.ModelViewSet):
    queryset = Activity.objects.all()
    serializer_class = ActivitySerializer
