from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ActivityViewSet
from tracker.views import home

# Set up the DRF router for the API
router = DefaultRouter()
router.register(r'activities', ActivityViewSet)

urlpatterns = [
    path('api/', include(router.urls)),  # The homepage
    path('home/', home, name='home'),
    path('api/', include(router.urls)),  # The API routes are prefixed with 'api/'
]
