from django.shortcuts import render
from rest_framework import generics
from .models import HydrationRecord  # Import your model
from .serializers import HydrationRecordSerializer

# View to render the HTML page for hydration tracking
def hydration_tracker_view(request):
    return render(request, 'hydration/hydration.html')

# List and create hydration records
class HydrationRecordListCreateView(generics.ListCreateAPIView):
    queryset = HydrationRecord.objects.all()  # Specify the queryset
    serializer_class = HydrationRecordSerializer

# Retrieve, update, or delete a single hydration record
class HydrationRecordDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = HydrationRecord.objects.all()  # Specify the queryset
    serializer_class = HydrationRecordSerializer
