from django.db import models
from django.utils import timezone

class HydrationRecord(models.Model):
    date = models.DateField(default=timezone.now)
    intake_ml = models.PositiveIntegerField()  # Intake in milliliters

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['date'], name='unique_date_record')
        ]

    def __str__(self):
        return f"Hydration on {self.date}: {self.intake_ml} ml"
