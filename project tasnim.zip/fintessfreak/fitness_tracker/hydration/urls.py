from django.urls import path
from .views import HydrationRecordListCreateView, HydrationRecordDetailView, hydration_tracker_view

urlpatterns = [
    path('api/hydration/', HydrationRecordListCreateView.as_view(), name='hydration-list-create'),
    path('home/hydration/', hydration_tracker_view, name=''),
    path('hydration/<int:pk>/', HydrationRecordDetailView.as_view(), name='hydration-detail'),
    
]
