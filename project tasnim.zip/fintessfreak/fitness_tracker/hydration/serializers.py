from rest_framework import serializers
from .models import HydrationRecord

class HydrationRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = HydrationRecord
        fields = ['id', 'date', 'intake_ml']
class HydrationRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = HydrationRecord
        fields = ['id', 'date', 'intake_ml']

    def validate_intake_ml(self, value):
        if value <= 0:
            raise serializers.ValidationError("Intake must be a positive value.")
        return value
